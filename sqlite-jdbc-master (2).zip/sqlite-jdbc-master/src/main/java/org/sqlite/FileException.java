package org.sqlite;

public class FileException extends Exception {
    public FileException(String message) {
        super(message);
    }
}
